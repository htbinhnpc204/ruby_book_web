class Student < ApplicationRecord
end
