class BookController < ApplicationController
  def index
  end
end
